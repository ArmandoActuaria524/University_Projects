public class Reservacion{

  //Atributos
  String id_reservacion;
  String nombre;
  int numero_acompanantes;
  int precio;
  int numero_Habitacion;
  int incluye_vuelo;
  int[] numero_Asientos_apartados_ida;
  int[] numero_Asientos_apartados_regreso;

  //Método constructor
  public Reservacion(String id,String n, int na, int p,int nh, int iv,int[] nai, int[] nar){
    id_reservacion=id;
    nombre=n;
    numero_acompanantes=na;
    precio=p;
    numero_Habitacion=nh;
    incluye_vuelo=iv;
    numero_Asientos_apartados_ida=nai;
    numero_Asientos_apartados_regreso=nar;

     }

    //GETTERS
    public String getId_reservacion(){
      return id_reservacion;
    }

    public String getNombre(){
      return nombre;
    }

    public int getNumeroAcompanantes(){
      return numero_acompanantes;
    }

    public int getPrecio(){
      return precio;
    }

    public int getNumeroHabitacion(){
      return numero_Habitacion;
    }

    public int getIncluyeVuelo(){
      return incluye_vuelo;
    }



    public String toString(){
      String cadena= "* Identificador ID: "+id_reservacion+
                    "\n* Nombre del titular y número de acompañantes: "+nombre+"   "+numero_acompanantes+
                    "\n* Precio: "+precio+
                    "\n* Número de habitación: "+(numero_Habitacion+1);


      String asientos_ida="";
      String asientos_regreso="";

      if(incluye_vuelo==1 && numero_Asientos_apartados_ida[0]!=0){ //Si la reservacion incluye vuelo...
        //Añadimos los valores de los arreglos que guardan los asientos reservados de cada avión
        for(int i=0; i<numero_Asientos_apartados_ida.length; i++){
          asientos_ida+= "A"+ numero_Asientos_apartados_ida[i] + " ";
          asientos_regreso+= "A"+ numero_Asientos_apartados_regreso[i] + " ";
        }

        

        //Imprimimos que sí incluye avión y los respectivos asientos que se reservaron en cada avión
        cadena+="\n* Incluye vuelo: Sí" + "\n* Asientos apartados en el vuelo de ida: "
        + asientos_ida + "\n* Asientos apartados en el vuelo de regreso: " + asientos_regreso;

      }else { //Si la reservación no incluye vuelo...
        //Imprimimos que no incluye avión
        cadena+="\n* Incluye vuelo: No";
      }

      return cadena;

    }

}
