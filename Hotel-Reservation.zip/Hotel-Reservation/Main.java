/*INTEGRANTES: 

  Castillo Pineda Ximena Isabel
  Guzman Baldovinos Jose Armando
   */

import java.util.*;
import java.io.Console;
import java.io.File;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
public class Main {


////////////////////////////////////////////////////////////////////////////////
/*Una vez creados los arregos deberemos darles un valor inicial a cada una de
las posiciones, en este caso el valor inicial será -1. */

  public static void DarValoresArreglo(int[] cadena) {
    for(int i=0; i<cadena.length; i++){
      cadena[i]=-1;
    }
  }

////////////////////////////////////////////////////////////////////////////////
/*Método para hacer una reservación en el hotel. El arreglo hotel tiene 15
posiciones que van desde 0 hasta 14, -1 significa que la habitación está vacía,
y 1 significa que está ocupada. Al cliente se le entrega la primer habitación
vacía que se encuentre al recorrer el arreglo, las habitaciones Sencillas
corresponden a las posiciones 0-4 y las Suites familiares a las posiciones
5-14 del arreglo. En caso de hacerse una reservación se regresa el número de 
la habitación, en caso contrario se regresa -1. */ 

  public static int ReservacionHotel(int[] hotel, int tipo_de_habitacion){
    //Booleano que nos permite saber si ya se ha asignado una habitación
    boolean asigno_habitacion=false;
    int n_habitacion=-1;
    
    //Se solicita una Habitación Sencilla 
    if(tipo_de_habitacion==1){
      //Se recorre el hotel de la habitación 0-4
      for(int i=0; i<=4; i++){
        //Si se encuentra un cuarto vacío y aún no asigna habitación...
        if((hotel[i]==-1) && (asigno_habitacion==false)){
          //guardamos la posición de la habitación encontrada
          n_habitacion=i;
          //La habitación cambia a ocupada al poner 1
          hotel[i]=1;
          asigno_habitacion=true;
        }
      }

    //Se solicita una Suite Familiar
    }else if((tipo_de_habitacion==2)){
      //Se recorre el hotel de la habitación 5-14
      for(int i=5; i<=14; i++){
        //Si se encuentra un cuarto vacío y aún no asigna habitación...
        if((hotel[i]==-1) && (asigno_habitacion==false)){
          //guardamos la posición de la habitación encontrada
          n_habitacion=i;
          //La habitación cambia a ocupada al poner 1
          hotel[i]=1;
          asigno_habitacion=true;
        }
      }
    }

    return n_habitacion;
  }

////////////////////////////////////////////////////////////////////////////////
/*Método para hacer reservación en el avión. Los arreglos avio_ida y avion_regreso
tienen 50 posiciones que van de 0-49, -1 significa que el asiento está disponible,
en otro caso se encontrará el número de la habitación de la persona que ha reservado
esos asientos. Se muestra en pantalla los asientos disponibles en el avión, el 
usuario introduce los números de asiento que quiere y estos se guardan en un arreglo
el cual será la variable de retorno. En caso de ya no haber asientos dispoibles el
método le asigna los asientos 0 a los pa*/

  public static int[] ReservacionAvion(int[] avion, int n_acompanantes, int n_habitacion){
    //Creamos el arreglo de retorno cuya longitud corresponde a la cantidad de pasajeros
    int[] asientos_de_avion=new int[n_acompanantes+1];

    //Contamos cuantos asietos están disponibles
    int contador=0;
    for(int j=0; j<50; j++){
      if(avion[j]==-1){
        contador++;
      }
    }

    /*Si la cantidad de asientos disponibles es menor a la cantidad de 
    pasajeros solicitada se mandará un mensaje diciendo que no se puede
    hacer la reservación*/
    if(contador<(n_acompanantes+1)){
      System.out.println("Lo sentimos, no hay asientos disponibles.");
      return asientos_de_avion;

    /*Si hay hacientos disponibles para cada pasajero entros se realiza
    el proceso de reservar asientos en el avion */
    }else{
      Scanner entrada =new Scanner(System.in);
      System.out.println("Se realizará la reservación de "+(n_acompanantes+1)+" pasajeros.");
      System.out.println("\nAsientos disponibles:");
      
      //Mostramos los asientos disponibles (aquellos cuyo valor es -1)
      
      for(int i=0; i<50; i++){
        if(avion[i]==-1){
          System.out.print("|A"+(i+1));
        }else if(avion[i]!=-1){
          System.out.print("|---");
        }
        //Hacemos un salto de línea por estética
        if((i+1)%10==0){
          System.out.print("| \n");
        }
      }

      for(int i=0; i<n_acompanantes+1; i++){
        //Mediante un try-catch verificamos que se introduzca un número 
        try{
          System.out.println("\nElija un número de asiento: ");
          int asiento=entrada.nextInt();
          //Guardamos el asiento elegido en el arreglo que vamos a regresar
          asientos_de_avion[i]=asiento;
          //Verificamos que el asiento elegido esté vacío
          if(avion[asiento-1]==-1){
            //Cambiamos el -1 por el número de habitación del titular
            avion[asiento-1]=n_habitacion;
            System.out.println("Asiento reservado exitosamente.");
            
          /*En caso de ya haber sido ocupado el asiento elegido se mostrará un mensaje
          y restaremos i-- impidiendo que proceda a seleccionar el asiento del siguiente
          pasajero*/
          }else if(avion[asiento-1]!=-1){
            System.out.println("Este asiento no esta disponible | Inténtelo otra vez.");
            i--;
          }
        
        //Verificamos que no se ingresen letras
        }catch(InputMismatchException e){
          System.out.println("Opción no válida | Ingrese un número.");
          i--;
          entrada.nextLine();
        //Verificamos que no se ingresen valores fuera del arreglo avión
        }catch(ArrayIndexOutOfBoundsException e){
          System.out.println("Opción no válida | Ingrese un número entre el 1 y 50.");
          i--;
          entrada.nextLine();
        }
      }
      return asientos_de_avion;
    }
    //return asientos_de_avion;
  }

////////////////////////////////////////////////////////////////////////////////
/* Generamos un ID aleatorio y regresamos el valor*/
  public static String IDAleatorio(){
    Random aleatorios=new Random();
    String id="";
    for(int i=0; i<=3; i++){
      int numero=aleatorios.nextInt(9)+1;
      id+= String.valueOf(numero);
    }
    return id;
  }

//////////////////////////////////// MAIN //////////////////////////////////////

  public static void main(String[] args) throws Exception {
    Scanner n=new Scanner(System.in);//Creamos una variable de tipo Scanner para leer el nombre
    Scanner entrada=new Scanner(System.in);//Creamos otra variable de tipo Scanner


    int [] hotel=new int[15];//Creamos un arreglo de tipo entero para las habitaciones del hotel
    int [] avion_ida=new int[50];//Creamos un arreglo entero para los asientos de ida del avion
    int [] avion_regreso=new int[50];//Creamos un arreglo para los asientos de regreso
    
    //Creamos 15 objetos de tipo de reservacion que es donde se guardarán todos los datos del cliente
    Reservacion r1=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r2=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r3=new Reservacion("", "", 0,0, 0, 0, null ,null);
    Reservacion r4=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r5=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r6=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r7=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r8=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r9=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r10=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r11=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r12=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r13=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r14=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    Reservacion r15=new Reservacion("", "", 0, 0, 0, 0, null ,null);
    
    //Creamos un arreglo de objetos de las reservaciones
    Reservacion [] registro=new Reservacion[]{r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15};
    
    //Lamamos al método DarvoresArreglo 
    DarValoresArreglo(hotel); //(-1,-1,....,-1)
    DarValoresArreglo(avion_ida); //(-1,-1,....,-1)
    DarValoresArreglo(avion_regreso); //(-1,-1,....,-1)
    
    String cancion = "";
    String extension = ".wav";
    int bandera = 2;
       while( bandera == 2){

    
    char opcion = 1;

    if (opcion==1) {


        cancion = "acensor";
    
    }

    try {
      Clip sonido = AudioSystem.getClip();
      sonido.open(AudioSystem.getAudioInputStream(new File ("Sounds/"+ cancion+extension)));
      sonido.start();
          //Creamos una variable entera para las opciones del menú
    int opciones=0;

     /*Iniciamos un ciclo while donde indicamos que las opciones 
     deben ser mayor-igual a cero o menor_igual a 6*/ 
    while(opciones>=0 || opciones<=6){

      opciones=0; //Igualamos nuevamente nuestra variable a cero para evitar confusiones
      
      //A través de un print presentamos el menú y las opciones que tiene
      System.out.println("\n\n—-----------------------------------------------------------------------");
      System.out.println("BIENVENIDO A LA AGENCIA PUMA-TOURS");
      System.out.println("Selecciona una de las siguientes opciones:");
      System.out.println(
      "\n   1. Crear reservación para el hotel Tropical."+
      "\n   2. Cancelar reservación."+
      "\n   3. Buscar reservación."+
      "\n   4. Ver todas las reservaciones."+
      "\n   5. Consultar el estatus de las habitaciones del hotel Tropical."+
      "\n   6. Consultar información del avión."+
      "\n   7. Salir del programa.");
      System.out.println("—-----------------------------------------------------------------------");
      
      /*Iniciamos un try-catch*/
      try{

        //nuestra variable opciones la igualamos para que lea enteros
        opciones=entrada.nextInt();
        
        
        /*Creamos un ciclo while para que muestre un mensaje en caso de que se digiten números
         menores_iguales que 0 o mayores-iguales a 7*/
        while(opciones<=0 || opciones>7){
          /*Se mostrará por pantalla un print para indicar que la
          opción no es valida y se pedirá nuevamente una entrada*/
          System.out.println("Opción no válida | Ingrese un número entre el 1 y 7.");
          //A través de un print presentamos el menú y las opciones que tiene
          System.out.println("\n\n—-----------------------------------------------------------------------");
          System.out.println("BIENVENIDO A LA AGENCIA PUMA-TOURS");
          System.out.println("Selecciona una de las siguientes opciones:");
          System.out.println(
          "\n   1. Crear reservación para el hotel Tropical."+
          "\n   2. Cancelar reservación."+
          "\n   3. Buscar reservación."+
          "\n   4. Ver todas las reservaciones."+
          "\n   5. Consultar el estatus de las habitaciones del hotel Tropical."+
          "\n   6. Consultar información del avión."+
          "\n   7. Salir del programa.");
          System.out.println("—-----------------------------------------------------------------------");
          opciones=entrada.nextInt();
        }
      /*Para la parte del catch indicamos la excepcion 
      InputMismatchException para en caso de que el usuario
      no digite una variable entera y el programa se siga ejecutando*/
      }catch(InputMismatchException e){
        /*Cuando se llegue a entrar al catch se imprimira por pantalla un mensaje */
       System.out.println("Opción no válida | Ingrese un número.");
        entrada.nextLine();
      }

      /*Adentro del mismo ciclo creamos el condicional
      en caso de que el usuario eliga la opción 1,2,3,...,6 o 7. */
      
      if(opciones==1){

       //HACER UNA RESERVACION
        /*EN ESTA OPCION SE LE PEDIRA AL cliente
        DIGITAR SU NOMBRE, NUMERO DE acompañantes
        SI EL NUMERO DE ACOMPAÑANTES ES MENOR A 2 ENTONCES SE LE DARA A ESCOJER ENTRE 
        UNA HABITACION SENCILLA O UNA SUITE FAMILIAR, EN CASO DE QUE SEAN MAYOR-IGUAL A 
        2 ENTONCES SE LE ASIGNARA AUTOMATICAMENTE UNA SUITE FAMILIAR Y SI INCLUYE VUELO 
        SE LE PEDIRA QUE ELIJA LOS ASIENTOS*/
        
        /*Dentro del condicional creamos las siguientes variables*/
      String nombre; //Variable String para el nombre del usuario
      int numero_de_acompanantes=0;//Variable entera para el número de acompañantes
      int incluye_vuelo=0;//Variable entera para indicar si la reservacion incluye vuelo
      int tipo_de_habitacion=0;//Variable entera para que indique el usuario su tipo de habitación
      int numero_de_habitacion=0;//Variable entera para indicar el numero de habitación del usuario
      int[] numero_de_asientos_ida=null;//Arreglo de tipo entero para indicar los asientos de ida del vuelo del cliente 
      int[] numero_de_asientos_regreso=null;//Arreglo de tipo entero para indicar los asientos de regreso del vuelo del cliente
      int precio=0;//Variable entera para el precio total de la reservación
      String ID="";//Variable String para dar el ID del cliente

      //A través del un print preguntamos el nombre del Titular 
      System.out.println("\n*Nombre del titular de la reservación: ");
      nombre = n.nextLine();/*Igualamos la variable nombre  a nuestra variable Scanner para que el usuario digite su nombre*/

      //A través de un Print preguntamos al cliente el número de acompañantes
      System.out.println("*Número de acompañanes del titular: ");
      //Iniciamos un ciclo while con un boolean True
      while(true){
        //Iniciamos un Try-Catch
        try{
          /*Dentro del while igualamos nuestra variable 
          acompañantes a nuestra variable Scanner para pedir 
          el numero de acompañanes*/
          numero_de_acompanantes=entrada.nextInt();
          /*A través de un condiconal restringimos para que el usuario no pueda elegir menos de 0 acompañantes y más de 4*/
          if((numero_de_acompanantes>=0) && (numero_de_acompanantes<=4)){
            //Si se cumple la condicion frenamos nuestro ciclo
            break;
          }else{
            /*En caso contrario se mostrara por pantalla
            que el número de acompañantes que se eligió es invalido*/
            System.out.println("El número de acompañantes no es válido "+
            "| Solo puede tener de 0 a 4 acompañantes.");
          }
          /*Para la parte del catch utilizamos InputMismatchException
          Para que el Scanner solo lea numeros enteros*/
        }catch(InputMismatchException e){
          /*Imprimimos por pantalla que la opción no es valida y que 
          escriba un número entero*/
          System.out.println("Opción no válida | Ingrese un número.");
          entrada.nextLine();
        }
      }
        /*En caso de que el número de acompañantes
        este enre 0 y 1 se dará a escoger el tipo de 
        habitación al cliente*/
      if((numero_de_acompanantes==0) || (numero_de_acompanantes==1)){
       /*Imprimimos para indicar que eliga un tipo de habitacion*/
        System.out.println( "*Eliga una categoría de habitación:" +
        "\n ---------------------------------------------------------------" +
        "\n | 1.Habitacion sencilla.                                        |" +
        "\n |    Costo: $580 por noche.                                     |" +
        "\n |    Habitación con una sola cama matrimonial.                  |" +
        "\n |    Capacidad máxima de 2 personas.                            |" +
        "\n └---------------------------------------------------------------┘\n" +
        " ---------------------------------------------------------------" +
        "\n | 2.Suit Familiar.                                              |" +
        "\n |   Costo: $1200 por noche.                                     |" +
        "\n |   Habitación con una cama kingsize y dos camas individuales.  |" +
        "\n |   Capacidad máxima de 5 personas.                             |" +
        "\n └---------------------------------------------------------------┘\n");
        
        /*Iniciamos un ciclo con una variable true para
        cuando el usuario va a elegir un tipo de habitacion*/
        while(true){
          //Iniciamos un try
          try{
            //Igualamos la variable tipo_de_habitacion a nuestro Scanner
            tipo_de_habitacion=entrada.nextInt();
            /*Creamos un condicional para que solo pueda elegir uno de los dos tipos de habitacion*/
            if((tipo_de_habitacion==1) || (tipo_de_habitacion==2)){
              /*En caso de que se cumpla saldremos del ciclo*/
              break;
            }else{
              /*En caso de que no se cumpla indicaremos
              que la opcion no es válida y el ciclo seguirá*/
              System.out.println("Opción no válida | Ingrese una de las opciones disponibles.");
            }
            /*Para el catch utilizamos InputMismatchException
            para que en caso de que no se digiten valores enteros 
            ell programa no se caiga*/
          }catch(InputMismatchException e){
            /*En caso de que no se digite un entero
            se mostrará por pantalla el siguiene mensaje*/
            System.out.println("Opción no válida | Ingrese un número.");
            entrada.nextLine();
          }
        }

      /*Este condicional es para que en caso de que el numero de acompañantes sea mayor-igual a 2 , 
      en automatico se le asignará una Suite Familiar*/
      }else if((numero_de_acompanantes>=2) || (numero_de_acompanantes<=4)){
        tipo_de_habitacion=2;
      }
        
      /*Este condicional es para que en caso de que al usuario tenga una habitación
      sencilla*/
      if(tipo_de_habitacion==1){
        /*Si esto se cumple entonces nuestra variable 
        numero_de_habitacion la igualamos a nuestro método 
        ReservacionHotel y le asigne un numero de habitacion al usuario*/
        numero_de_habitacion = ReservacionHotel(hotel, 1);
        /*Anidamos un condicional en caso de que
        el usuario eliga una habitacion sencilla y ya no se
        tengan disponibles*/
        if(numero_de_habitacion==-1){
          /*Si esto se cumple se mostrara por pantalla que 
          ya no hay habitaciones sencillas disponibles*/
          System.out.println("Lo sentimos, no hay Habitaciones Sencillas disponibles.");
          boolean b=true; /*Creamos un boolean true*/
         
         /*Iniciamos un ciclo for*/
          for(int i=0; i<=14; i++){
            /*Dentro de nuestro ciclo creamos un condicional 
            para que en caso de que exista una habitacion
            de Suit familiar y nuestro boolean sea true*/
            if((hotel[i]==-1) && (b==true)){
              /*Si esto se cumple le preguntaremos al usuario
              que si desea cambiar su habitación a Suit Familiar*/
              System.out.println("¿Desea cambiar su habitación por una Suit Familiar?   1. Sí. / 2. No.");
            //Iniciamos un ciclo con una variable true
              while(true){
                /*Iniciamos un try*/
                try{
                  /*Creamos una variable entera igualada a nuestro 
                  Scanner*/
                  int otra_habitacion=entrada.nextInt();
                  /*Condicional para en caso de si elige cambiar
                  a la Suit Familiar*/
                  if(otra_habitacion==1){
                    /*Si esto se cumple, el numero de habitacion lo
                    igualamos a nuestro metodo ReservacionHotel y
                    le asignamos una suite Familiar*/
                    numero_de_habitacion = ReservacionHotel(hotel, 2);
                    /*Luego a nuestra variable precio le vamos
                    sumando los costos de hospedaje*/
                    precio+=1200*5;
                    /*Por medio de un print se indicara que tipo de habitacion se asignó y despúes el precio a pagar por el hospedaje*/
                    System.out.println("\nSe le asignó una Suite Familiar. "+
                    "El precio por noche es de $1200,"+
                    " el costo total de hospedaje es $"+precio+".");
                    break;//Detenemos nuestro ciclo

                  }else if(otra_habitacion==2){
                    /*En caso de que el cliente no quisiera 
                    cambiar de habitación se frenara igual el ciclo y saldrá el menú principal*/
                    break;
                  }
                  /*Para la parte del Catch utilizamos 
                  InputMismatchException para que en caso de que 
                  no se digite una variable entera, el programa no se caiga */
                }catch(InputMismatchException e){

                  /*A través de un print indicaremos que la opcion
                  no es válida*/
                  System.out.println("Opción no válida | Ingrese 1 o 2.");
                  entrada.nextLine();
                }
              }
              //Igualamos nuestro boolean a false
              b=false;
            }
          }

        }else{
          /*En caso de que el cliente elija una habitación sencilla
          y si haya en existencia entonces a la variable precio se le sumará los costos de hospedaje*/
          precio+=580*5;

          /*Se imprimirá por pantalla que se le asignó una habitación sencilla y el costo por el hospedaje*/
          System.out.println("\nSe le asignó una Habitación Sencilla. "+
          "\nEl precio por noche es de $580,"+
          " el costo total de hospedaje es de $"+precio+".");
        }


        /*Este condicional es para el caso de que al usuario se le asigne o elija una suite familiar*/
      }else if(tipo_de_habitacion==2){
        /*Si se cumple esto , nuestra variable numero_de_habitacion
        la igualamos a nuestro método ReservacionHotel y le asignamos un numero de habitacion en nuestro
         arreglo hotel*/
        numero_de_habitacion = ReservacionHotel(hotel, 2);
        
        /*Creamos este condicional en caso de queremos
        no haya disponibles suite Familiar y exista
        por lo menos una habitacion sencilla*/
        if(numero_de_habitacion==-1){
          /*Si se cumple se imprime por pantalla que no haya Suites familiares*/
          System.out.println("Lo sentimos, no hay Suites Familiares disponibles.");
          /*Creamos un boolean true*/
          boolean b=true;
          
          /*Iniciamos un ciclo for en torno a las habitaciones sencillas */
          for(int i=0; i<=4; i++){
            /*Condicionamos para que en nuestro
            arrelgo hotel busque si hay alguna habitancion sencilla disponible, el boolean
            sea igual a true y el numero de acompañantes
            sea menor-igual a 1*/
            if((hotel[i]==-1) && (b==true) && (numero_de_acompanantes<=1)){
              /*Si esto se cumple se prengutara
              a través de un print, si desea 
              cambiar su suite por una habitacion sencilla*/
              System.out.println("¿Desea cambiar su habitación por una Habitación Sencilla?   1. Sí / 2. No.");
          /*Iniciamos un ciclo while 
          con una variable true*/
              while(true){
                //Iniciamos un try
                try{
                  /*Creamos una variable entera igualada a un Scanner para crear una reservacion*/
                  int otra_habitacion=entrada.nextInt();
                  
                  /*Condicionamos para que en caso de que nuestro cliente cambie a la habita sencilla */          
                  if(otra_habitacion==1){
                    /*igualamos la variable número de habitación al metodo
                    ReservacionHotel para que le asigne una habitacion sencilla en el arreglo hotel*/
                    numero_de_habitacion = ReservacionHotel(hotel, 1);
                    
                    /*A la variable precio le asignamos los costos por hospedaje*/
                    precio+=580*5;
                    /*Imprimimos por pantalla El tipo de habitacion que se asignó y le mostramos el precio por el 
                    hospedaje*/
                    System.out.println("\nSe le asignó una Habitación Sencilla. "+
                    "\nEl precio por noche es de $580,"+
                    " el costo total de hospedaje es de $"+precio+".");
                    
                    break;//Frenamos nuestro ciclo

                    /*En caso de que el usuario no quiera una hanitacion sencilla también se frenara el ciclo 
                    y saldrá al menú principal*/
                  }else if(otra_habitacion==2){
                    break;
                  }
                /*Para el catch utilizamos InputMismatchException para que en caso de que  no se digite un número
                entero no se cierre el programa*/         
                }catch(InputMismatchException e){
                /*Se imprimira por pantalla
                que la opcion no es valida*/
                System.out.println("Opción no válida | Ingrese 1 o 2.");
                entrada.nextLine();
                }
              }
            //Igualamos nuestro boolean a false
              b=false;
            }
          }
        /*En caso de que sí exista suite familiar disponible a la variable precio se le sumara el costo de 
         hospedaje y se imprimira por pantalla que se asignó suite familiar y el precio*/
        }else{
          precio+=1200*5;
          System.out.println("\nSe le asignó una Suite Familiar. "+
          "\nEl precio por noche es de $1200,"+
          " el costo total de hospedaje es de $"+precio+".");
        }

      }
      /*Creamos un condicional en caso de que ya se haya realizado una reservación de habitacion*/
      if(numero_de_habitacion!=-1){

        /*Si  se cumple  imprimimos preguntando
        al cliente si quiere incluir boletos de avión*/
        System.out.println("\nEl costo de incluir boletos de avión al viaje es"+
        "de $4000 por persona y es \nvuelo redondo. *¿Desea incluir vuelos? 1. Sí. / 2. No.");
        /*iniciamos un ciclo con una variable true*/
        while(true){
           
          /*Iniciamos un try*/
          try{
            /*Nuestra variable incluye vuelo la igualamos a nuestro scanner*/
            incluye_vuelo=entrada.nextInt();
            
            /*Creamos un condicional para que 
            el usuario solo pueda digitar 1 o 2*/
            if(incluye_vuelo==1 || incluye_vuelo==2){
              break;//frenamos el ciclo 
            }else{
              /*Si se digita un numero diferente de 1 y 2 se mostrara por pantalla 
              que no es valido*/
              System.out.println("Opción no valida | Ingrese 1 o 2.");
            }

            /*Para el catch usamos InputMismatchException para en caso de que el usuario digite un numero no entero*/
          }catch(InputMismatchException e){
          System.out.println("Opción no valida | Ingrese un número.");
          entrada.nextLine();
          }
        }

        /*Creamos un condicional en caso de que el usuario decida incluir vuelo*/
        if(incluye_vuelo==1){
        
          System.out.println("\n ---Reserve sus asientos para el vuelo de ida.---");
          /*Si esto se cumple le diremos
          que elija sus numero de asientos de ida y la variable asientos ida la igualamos al método ReservacionAvion con el Arreglo avion_ida*/
          numero_de_asientos_ida=ReservacionAvion(avion_ida, numero_de_acompanantes, numero_de_habitacion);
          /*Una vez hecho eso le pedimos al usuario que digite sus asientos de regreso
          y llamamos al método ReservacionAvion con el arreglo avion_regreso*/
          System.out.println("\n ---Reserve sus asientos para el vuelo de regreso.---");
          numero_de_asientos_regreso=ReservacionAvion(avion_regreso, numero_de_acompanantes, numero_de_habitacion);

          if((numero_de_asientos_ida[0]==0) || (numero_de_asientos_ida==null)){
            System.out.println("\nNo se han podido reservar vuelos.");
          }else{
            /*A la variable precio le sumamos el costo del vuelo multiplicado por el numero de acompañanes más el cliente*/
          precio+= 4000*(numero_de_acompanantes+1);
          }
          
        }

      }


      //Generamos un ID único
      /*Llamamos al metodo IDAleatorio*/
      ID=IDAleatorio();
      /*A través de un ciclo for verificamos que ninguna reservación tenga el mismo ID,
      de ser así se genera nuevamente el ID con el método IDAleatorio y se vuelve a
      iniciar el ciclo for*/
      for(int i=0; i<=14; i++){
        if(registro[i].getId_reservacion().equals(ID)){
          ID=IDAleatorio();
          i=0;
        }
      }


    /*Creamos una variable de tipo entera igualada a 0*/
      int i=0;

      /*Iniciamos un ciclo donde nuestra variable
      sea menor a 15*/
      while(i<15){
        /*Creamos un condicional dentro del ciclo donde si nuestro arrelgo de objetos en la
        posicion i y llamando al nombre del usuario, este parametro esta vacio*/
        if((registro[i].getNombre()=="") && (numero_de_habitacion!=-1)){
          /*Si esto se cumple, los anteriores datos que el usuario digito en la reservación
          se guardaran en un lugar de nuestro arreglo de objetos */
          registro[i] = new Reservacion(ID, nombre, numero_de_acompanantes, precio, numero_de_habitacion, incluye_vuelo, numero_de_asientos_ida , numero_de_asientos_regreso);

          /*Creamos un timer para indicar
          que la informacion se esta "almacenando"*/
          System.out.println();
          Thread.sleep(1000);
          for( int j= 3; j>=1; j--){
            System.out.printf("Almacenando información en... %d\r", j);
            Thread.sleep(1000);
          }
          /*Imprimimos que la reservacion fue realiada con exito */
          System.out.println();
          Thread.sleep(500);
          System.out.println("\nRESERVACIÓN REALIZADA CON ÉXITO.");
          Thread.sleep(500);
          System.out.println("");
          System.out.println(registro[i]);
          Thread.sleep(1000);
          System.out.printf("");
        /*Despues creamos un timer para indicar que estamos volviendo al menú principal*/
          for( int h= 5; h>=1; h--){
            System.out.printf("Regresando al menú en.... %d\r", h);
            Thread.sleep(1000);
          }
          break; /*frenamos el ciclo*/

        //Si no se encontró una habitación disponible se manda un mensaje y regresará al menú
        }else if(numero_de_habitacion==-1){
          System.out.println("");
          System.out.println("No se puede realizar su reservación.");
          Thread.sleep(1000);
          /*Despues creamos un timer para indicar que estamos volviendo al menú principal*/
          for( int h= 5; h>=1; h--){
      System.out.printf("Regresando al menú en.... %d\r", h);
            Thread.sleep(1000);
          }
          break; /*frenamos el ciclo*/
        } 

        i++;
      }/*Aqui termina el ciclo while para guardar el registro en nuestro arreglo de objetos*/


      }else if(opciones==2){

        //CANCELAR UNA RESERVACIÓN
      /*Se pido al usuario un ID y se comprueba que exista una habitación con dicho ID,
      en caso de existir se pregunta si realmente se quiere cancelar la reservación,
      si no se da un número entre 1 y 2 se regresará al menú. Por otro lado si el ID
      no coincide con el ID de ninguna habitación se mostrará un mensaje y te devolverá
      al menú*/
      
        boolean id_aceptada=false; //Boolean que no dirá si el ID ingresado existe
        System.out.println("\nEscribe tu ID para cancelar la reservación: ");
        String cancelar=entrada.next();
        int confirmacion=0;
        
        /*Recorremos todos los registros (el arreglo resgistro) y nos preguntamos
        si el ID de alguno de ellos es igual al ID que nos acaban de introducir*/
        for(int j=0; j<=14; j++){
          if(cancelar.equals(registro[j].getId_reservacion())){
            System.out.println("¿Está seguro de querer cancelar la reservación?   1. Sí."+" 2. No.");

            while(confirmacion>=1 || confirmacion<=2){
              confirmacion=0;
            //Verificamos que se introduzca un número
            try{
              confirmacion=entrada.nextInt();
              //Mientras no se de un número entre 1 y 2 seguirá pidiendo una entrada al usuario
              while(confirmacion<1 || confirmacion>2){
                System.out.println("Opción inválida");
                confirmacion=entrada.nextInt();
              }
       
            }catch(InputMismatchException e){
                  System.out.println("Opción no valida");
                  entrada.nextLine();
            }

            //Cancelamos la reservación

            if(confirmacion==1){
              //Desocupamos la habitación de hotel al vover el valor a -1
              hotel[registro[j].getNumeroHabitacion()]=-1;
              /*Desocupamos los asientos del avión volviendo -1 a aquellos
              asientos que tengan el número de la habitación de la reservación
              que queremos cancelar*/
              for(int h=0; h<=49; h++){
                if(avion_ida[h]==registro[j].getNumeroHabitacion()){
                  avion_ida[h]=-1;
                }
                if(avion_regreso[h]==registro[j].getNumeroHabitacion()){
                  avion_regreso[h]=-1;
                }
              }

              //Regresamos los valores de la reservación a sus valores iniciales
              registro[j] = new Reservacion("", "", 0, 0, 0, 0, null , null);
              //Indicamos que la ID sí existe y ha sido aceptada
              id_aceptada=true;
              j=15;
              //Imprimos que la reservación fue cancelada
              System.out.println("\nRESERVACIÓN CANCELADA CON ÉXITO.");

              //Regresamos al menú
              Thread.sleep(1000);
              for( int f =3; f>=1; f--){
              System.out.printf("Regresando al menú en... %d\r", f);
              Thread.sleep(1000);
              }
              break;
            }else if(confirmacion==2){ //Se decide no cancelar la reservación
              //Indicamos que la ID fue aceptada
              id_aceptada=true;
              //Regresamos al menú
              
              
              for( int f =3; f>=1; f--){
              System.out.printf("Regresando al menú en... %d\r", f);
              Thread.sleep(1000);
              
              }
              break;
            }
          }


          }

        }
        
      //Si el ID no fue encontrado dirá que es inválido
      if(id_aceptada==false){
        System.out.println("ID inválido");
        System.out.println("***************************");
      }


      }else if(opciones==3){
        
          //BUSCAR RESERVACIÓN
        /*Se pide al usuario que ingrese un ID y posteriormete se verifica que
        alguna de las habitación coincida con dicho ID, en caso de ser así se
        mostrará la información de la habitación; en caso contrario el usuario
        tendrá dos intentos más, después del tercero se le regresará al menú*/
        
        boolean id_aceptada=false; //boolean con el que sabremos si el ID existe
        int i=3;
        while(i>0){
          System.out.println("\nEscribe un ID para consultar la información."+
          "    "+" Intentos; "+i);
          String informacion=entrada.next();
          
          /*Recorremos todos los registros (el arreglo resgistro) y nos preguntamos
          si el ID de alguno de ellos es igual al ID que nos acaban de introducir*/
          for(int j=0; j<=14; j++){
            if(informacion.equals(registro[j].getId_reservacion())){
              //Imprimimos a partir del método toString de la clase
              System.out.println(registro[j]);
              //Indicamos que el ID fue aceptado
              id_aceptada=true;
              //Detenemos el ciclo for
              j=15;
              //Evitamos volver a entrar al ciclo while
              i=-1;
            }
          }
          
          //Si el ID no fue encontrado dirá que no existe dicha reservación
          if(id_aceptada==false){
            System.out.println("Reservación inexistente | Inténtelo otra vez.");
            i--;
          }
          
          //El número de intentos llega a 0
          if(i==0){
            System.out.println("\nNúmero de intentos superado.");
          }
          
        }
        
        //Regresamos al menú
        Thread.sleep(1000);
        for( int f =3; f>=1; f--){
          System.out.printf("Regresando al menú en... %d\r", f);
          Thread.sleep(1000);
        }
        

      }else if(opciones==4){
        
          //VER TODAS LAS RESERVACIONES 
        /*Sabemos que una una reservación está vacía porque su ID está vacío.
        Recorremos todos los registros e imprimimos con el método toString
        de la clase solo aquellos registros que no tengan un ID vacío.*/
        
        for(int i=0;i<registro.length;i++){
          if(registro[i].getId_reservacion()!=""){
            System.out.println("************************************************************************");
            System.out.println(registro[i]);
            System.out.println("************************************************************************\n");
          }
        }


      }else if(opciones==5){
        
          //CONSULTAR EL STATUS DE LAS HABITACIONES HOTEL-“TROPICAL"
        /*Sabemos que una habitación de hotel está desocupada si tiene un -1,
        en otro caso si tiene un 1 significa que está ocupada.*/

          for(int i=0; i<=14; i++){
          /*El arreglo hotel cuenta con habitaciones que van de 0-14; sin
          embargo al usario se me muestran desde 1-15, por lo que a la posición
          del arreglo le sumamos 1 al imprimir*/
          System.out.print("\nHabitacion "+(i+1)+": ");
          if(hotel[i]==-1){
            System.out.println("desocupada.");
          }else if(hotel[i]==1){
            System.out.println("ocupada.");
          }
        }

      }else if (opciones==6){
        
          //CONSULTAR INFORMACIÓN DEL AVIÓN
        /*Sabemos que un asiento de avión está descupado si tiene un -1, por
        ora parte un número distinto a este significa que está ocupado, pues
        debería tener el número de la habitación de la persona que lo reservó.*/
        
        System.out.println("\nPulsa ENTER para ver los asientos de ida.");
        Console consola = System.console(); //instanceando
        consola.readPassword();
        
        /*Los arreglos avion_ida y avion_regreso cuentan con asientos que van de 0-14;
        sin embargo al usario se me muestran desde 1-50, por lo que a la posición
        del arreglo le sumamos 1 al imprimir*/

        //Recorremos el avión de ida
        System.out.println("\nAsientos de ida");
       for(int i=0; i<50; i++){
      if(avion_ida[i]==-1){
        System.out.print("|A"+(i+1));//Muestra asientos disponibles
      }else if(avion_ida[i]!=-1){
         System.out.print("|---");/*Muestra asientos ocupados */
      }
      //Hacemos un salto de línea por estética
      if((i+1)%10==0){
        System.out.print("| \n");
      }
    }
      
      /*  for (int i=0;i<=49 ;i++ ) {
          System.out.println("\nA"+(i+1)+"; ");

          if (avion_ida[i]==-1) {
            System.out.println("Disponible.");
          }else if(avion_ida[i]!=-1){
            System.out.println("Ocupado.");
          }
        }*/

        System.out.println("\nPulsa ENTER para ver los asientos de regreso.");
        consola = System.console(); //instanceando
        consola.readPassword();
        System.out.println("Asientos de regreso");
        //Recorremos el avión de regreso
      for(int i=0; i<50; i++){
      if(avion_regreso[i]==-1){
        System.out.print("|A"+(i+1));
      }else if(avion_regreso[i]!=-1){
         System.out.print("|---");
      }
      //Hacemos un salto de línea por estética
      if((i+1)%10==0){
        System.out.print("| \n");
      }
    }

      }else if(opciones==7){

        //TERMINA EL PROGRAMA

        break; //Salimos del ciclo principal
      }



    }

      Thread.currentThread().sleep(0000);
      sonido.close();

      if (opciones==7) {
        break;
      }
     

    } catch(Exception e) {
      System.out.println("" + e);
    }
    
  }
  }
}
