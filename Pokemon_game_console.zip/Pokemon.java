import java.util.*;



public class Pokemon{

		String nombre;//Nombre del Pokemon
		String tipo;//Tipo de Pokemon(Agua,tierra,Plantita,Fuego, etc.)
		int energíaVital;//Energía del Pokemon
		boolean confundio;//False No esta confundido, True si lo está
		Mochila mochila;//Llamamos a la clase mochila y se lo asignamos con atributo a nuestro Pokemon
		int velocidad;//Velocidad del pokemon
		


		//Metodo Constructor
	public Pokemon(String n ,String t ,int ev, boolean c , Mochila m,int v){
		//A cada atributo se le asigna una letra
		nombre=n;
		tipo=t;
		energíaVital=ev;
		confundio=c;
		mochila=m;
		velocidad=v;
	
	}

		//Setters


		public void setNombre(String n){
			
			nombre=n;
		
		}

		public void setTipo(String t){

			tipo=t;
		
		}


		public void setEnergiaVital(int ev){

			energíaVital=ev;
		
		}


		public void setConfundido(boolean c){

			confundio=c;
		
		}

		public void setMochila(Mochila m){

			mochila=m;
		}

		public void setVelocidad(int v){

			velocidad=v;
		}



		//Getters


		public String getNombre(){

			return nombre;
		
		}

		public String getTipo(){

			return tipo;
		}

		public int getEnergiaVital(){

			return energíaVital;
		
		}

		public boolean getConfundido(){

			return confundio;

		}


		public Mochila getMochila(){

			return mochila;

		}

		public int getVelocidad(){

			return velocidad;


		}
	
		


		//Método para la Batalla Pokemon
		//Lo hacemos en funcionn de  los Pokemones y sus mochilas ya que serán de importancia

		public void pelear(Pokemon p1, Pokemon p2,Mochila m1,Mochila m2){

		Scanner entradas=new Scanner(System.in);//Establecemos un Scanner para que el usuario "Juegue"
		Random aleatorios=new Random();//Un random que Utilizaremos para lo de confundido


		/*Llamamos al Oran Berry de las mochilas y le asignamos una variable de tipo entera 
		para manipularla mejor*/
		int obp1=m1.getOranBerry();
		int obp2=m2.getOranBerry();
		/*Llamamos a las monedas  de las mochilas y le asignamos una variable de tipo entera 
		para manipularla mejor*/		
		int mp1=m1.getMonedas();
		int mp2=m2.getMonedas();
		/*Llamamos al Elixir  de las mochilas y le asignamos una variable de tipo entera 
		para manipularla mejor*/	
		int ep1=m1.getElixir();
		int ep2=m2.getElixir();
				
		//Metémos la Energía vital de los pokemones para utilizarla en la Pelea
		int ev1=p1.getEnergiaVital();
		int ev2=p2.getEnergiaVital();
		
		//Pokemon1	
		
		/*Establecemos 4 contadores para los poderes que tendrán un valor inicial de 7
		peroo irán disminuyendo cada vez que se usen*/
		int poder1p1=7;
		int poder2p1=7;
		int poder3p1=7;
		int poder4p1=7;
		

		//Pokemon2
		//Analogo a lo anterior para el pokemon 2
		int poder1p2=7;
		int poder2p2=7;
		int poder3p2=7;
		int poder4p2=7;
	
		/*Establecemos un boolean para los turnos*/
		boolean pokemon2turn=true;
		//Establecemos un print para presentar a los Pokemones en la Arena
		System.out.println("\nNuestros pokemones " + p1.getNombre() +" de tipo "+p1.getTipo()+" y "+ p2.getNombre() + " de tipo "+
								p2.getTipo()	+" se enfrentaran en una batalla pokemon :O");
		System.out.println("\n*********************************************");					


		//Atacará el Pokemon más rápido y lo establecemos en un if		
		if(p2.getVelocidad()>p1.getVelocidad()){

		System.out.println("\nAtacara primero " +p2.getNombre()+" por ser mas veloz");
		
		/*Iniciamos un ciclo en funcion de la energía de cada pokemon
		Si estas dos son mayores a cero entonces iniciará la pelea*/
		while(ev1>0 && ev2>0){
					
					//Raichu poderes
					int voltiocambio=14;
					int chispa=6;
					int trueno=60;
					int encanto=20;

					//Charmander Poderes
					int lanzallamas=70;
					int ascuas=10;
					int araniazo=6;
					int pirotecina=25;

					/////////////
					/*Establecemos dos variables enteras para cuando
					  se eligan los poderes*/
					int ataque1;
					
					int ataque2;

			/*Establecemos un if con la condicion del Boolean y le asignamos el 
			turno al pokemon más veloz*/
			if(pokemon2turn){
				
				//Se establece un menú con varos Print para elegir los ataques
				System.out.println("\nTurno de "+p2.getNombre()+":  Su vitalidad actual es " +ev2);

				System.out.println("\nElige un ataque:");
				System.out.println("\n1.Voltiocambio  Danio:14");
				System.out.println("2.Chispa  Danio:6");
				System.out.println("3.Trueno  Danio:60");
				System.out.println("4.Encanto  Danio:20");
				System.out.println("5.Beber Elixir");
				 //Se utiliza el int ataque para el Scanner
				 ataque1=entradas.nextInt();
				
				 /*Se establece un condicional de que si el usuario elige un ataque
				  y el contador del ataque es igual a cero entonces ya no puede usar el Ataque
				  */
			if (ataque1==1 && poder1p2==0) {
						System.out.println("\nYa no puedes usar Voltiocambio");
						System.out.println("\nLa vitalidad de "+p1.getNombre()+" es "+ev1);
				/*Si eso no pasa entonces puede usar el ataque y comenzar a restarle vida al oponente*/		
			} else if(ataque1==1 ){
					
					ev1-=voltiocambio;
					System.out.println("\nAtacaste con volticambio");			
					System.out.println("\nLa vitalidad de "+p1.getNombre()+" es "+ev1);
					poder1p2--;
					

								

			//Lo anterior es analogo para los demás poderes
		 }else if (ataque1==2 && poder2p2==0) {
						System.out.println("\nYa no puedes usar chispa");
						System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
						
					

		}else if (ataque1==2) {
					
					ev1-=chispa;
					poder2p2--;
									
					System.out.println("\nAtacaste con chispa ");
					System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
				


		}else if (ataque1==3 && poder3p2==0) {
						System.out.println("\nYa no puedes usar trueno");
						
						System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
						
		}else if(ataque1==3){
					
					
					ev1-=trueno;
					System.out.println("\n Atacaste con Trueno");
					System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);


					poder3p2--;
							
				

		}else if (ataque1==4 && poder4p2==0) {
						System.out.println("\nYa no puedes usar Encanto");
						System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
						
					

		}else if(ataque1==4){
					
					ev1-=encanto;
					System.out.println("\nAtacaste con Encanto");
					System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
					poder4p2--;

			/*Aqui se establece una quinta opción y es la de beber Elixir*/			
			} if(ataque1==5){ 
			
				//Establecemos un ciclo for
			for (int j=0;j<2 ;j++ ) {
				/*Y este if en funcion del Boolean servirá para que una vez que 
				  se utilice el elixir, el pokemon tenga la oportunidad de atacar*/
				if(pokemon2turn){
			 	
			 
					//Primero establecemos una condición de que si el Elixir es cero ya no se puede utilziar
				if(ep2==0){
					System.out.println("\nLo siento ya no puedes beber Elixir otra vez ");
				
					/*En caso de que los todos los poderes esten llenos
						se condicionan que aun no se puede usar elixir*/
				}else if( poder1p2==7 && poder2p2==7 && poder3p2==7 && poder4p2==7){
				System.out.println("\nAún no puedes beber Elixir, aun tienes completos todos tus ataques");
			}/*Basta con que alguno de los poderes sean menor a 7 para que
				se pueda beber el Elixir y reestablecer los poderes*/
			else if(ataque1==5 || poder1p2<7 || poder2p2<7 || poder3p2<7 || poder4p2<7){
				
				/*Operamos sumandole al poder la variable en el que metimos al elixir de la mochila*/
						poder1p2+=ep2;
						poder2p2+=ep2;
						poder3p2+=ep2;
						poder4p2+=ep2;
						//E igualamos a cero el elixir para que no se pueda usar otra vez
						ep2=0;
						
						/*Si por alguna razón algun poder cuando se regenere
						  es mayor a 7, se anido un if en el que se iguala a 7 para que
						  no sobrepase el limite*/
						if( poder1p2>7 || poder2p2>7 || poder3p2>7 || poder4p2>7){
						poder1p2=7;
						poder2p2=7;
						poder3p2=7;
						poder4p2=7;
						
						}
						System.out.println("\nRecargaste todos tus ataques");

					

				}		//Se pone el boolean a false para pasar al sig turno
						pokemon2turn=false;
			}
		}
			}
	
		/*Para hacer la pelea más interesante se condiciono
		 que solo se puede utilizar el Oran Berry en caso de que 
		 la vitalidad sea menor o igual a 300*/


		 /*En caso de que la vitalidad sea menor o igual a 300
		 	y el oran berry este vacio se mostrara que ya no se puede usar*/
		if(ev2<=300 && obp2==0){
					System.out.println("\nLo siento ya consumiste todo tu Oran berry , no podras aumentar tu vitalidad");
		
		/*En caso de que solo la vitalidad sea menor o igual a 300
		se mostrará una pequeño menu de que la vitalidad se esta agotando
		y da la opcion de usar o no usar el Oran Berry*/
		}else if(ev2<=300){
					System.out.println("\nTu Vitalidad se esta agotando");
					System.out.println("\nPulsa 1 para usar OranBerry");
					System.out.println("\nPulsa 2 para denegar");
					//Establecemos un entero con un Scanner para que el usuario elija
					int ob1=entradas.nextInt();
			
		/*Si se elige la opción 1 se le agregara el oran berry
		Y se mostrará por pantalla que se ha recargado la energía*/
		if(ob1==1){
					ev2+=obp2;
					obp2=0;
					System.out.println("\nRecargaste tu energía a "+ ev2);
									
		//En caso contrario se mostrará un mensaje ante la negacion de la primera opción			
		}else if(ob1==2){
					System.out.println("\nUsalo cuando puedas");
					}
				} 
				/*El siguiente if se establecion en funcion en que
				si el usuario elige la opcion en la que un poder es mayor a 40
				 y el poder no se ha usado más de 7 veces*/
				if(ataque1==3 && trueno>=40 && poder3p2>0){
						//Establecemos dos random para las probabilidades
						

						//Confundir
						int confundidop1=aleatorios.nextInt(100)+1;
						//Fallar
						int fallarp1=aleatorios.nextInt(100)+1;
						

					/*Anidamos un if en el que si el random de confundir
					entra en un rango de 20 y 100 (80%)
					Entonces llamamos al setConfundir del rival y le ponemos true  */
					if( confundidop1>=20 && confundidop1<=100){
						p1.setConfundido(true);
						System.out.println("\n "+p1.getNombre() +"  Esta confundido :(");
						

						/*Anidamos este if para en caso de que
							se cumpla la condicion anterior en tonces
							se establece un if de que si confundido es true 
							y el random fallar esta entre 40 y 100(60%)
							Entonces el rival falla dos turnos*/
				if(p1.getConfundido()==true  && fallarp1>=40 && fallarp1<=100){
					//Establecemos un ciclo for para que dure solo dos veces
				for (int i=0;i<3 ;i++ ) {
				/*Y le asignamos al pokemon que halla atacado otros dos turnos*/
				if(pokemon2turn){
				/*Se establece un print para decir quien falla dos turnos*/
				System.out.println("\nFallas dos turnos " +p1.getNombre());
				System.out.println("********************************");				
				
				/*Y luego sigue quien atacará dos turnos seguidos*/
				System.out.println("\nTurno de "+p2.getNombre()+":  Su vitalidad actual es " +ev2);
				
				/*Aquí se establce todo lo relacionado al turno como los ataques,
				tomar elixir, el Oran berry, ya que así es como el for
				durará dos veces y en concecuencia el pokemon que haya atacado con un poder
				de más de cuarenta pueda tener otros dos turnos*/
				System.out.println("\nElige un ataque:");
				System.out.println("\n1.Voltiocambio  Danio:14");
				System.out.println("2.Chispa  Danio:6");
				System.out.println("3.Trueno  Danio:60");
				System.out.println("4.Encanto  Danio:20");
				System.out.println("5.Beber Elixir");
				 ataque1=entradas.nextInt();
				

			if (ataque1==1 && poder1p2==0) {
						System.out.println("\nYa no puedes usar Voltiocambio");
						System.out.println("\nLa vitalidad de "+p1.getNombre()+" es "+ev1);
						
			} else if(ataque1==1 ){
					
					ev1-=voltiocambio;
					System.out.println("\nAtacaste con volticambio");			
					System.out.println("\nLa vitalidad de "+p1.getNombre()+" es "+ev1);
					poder1p2--;
					

								


		 }else if (ataque1==2 && poder2p2==0) {
						System.out.println("\nYa no puedes usar chispa");
						System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
						
					

		}else if (ataque1==2) {
					
					ev1-=chispa;
					poder2p2--;
									
					System.out.println("\nAtacaste con chispa ");
					System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
				


		}else if (ataque1==3 && poder3p2==0) {
						System.out.println("\nYa no puedes usar trueno");
						
						System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
						
		}else if(ataque1==3){
					
					
					ev1-=trueno;
					System.out.println("\n Atacaste con Trueno");
					System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);


					poder3p2--;
							
				

		}else if (ataque1==4 && poder4p2==0) {
						System.out.println("\nYa no puedes usar Encanto");
						System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
						
					

		}else if(ataque1==4){
					
					ev1-=encanto;
					System.out.println("\nAtacaste con Encanto");
					System.out.println("\nLa Vitalidad de "+p1.getNombre()+" es "+ev1);
					poder4p2--;

			} if(ataque1==5){ 
			

			for (int j=0;j<2 ;j++ ) {
				if(pokemon2turn){
			 	
			 

				if(ep2==0){
					System.out.println("\nLo siento ya no puedes beber Elixir otra vez ");
				

				}else if( poder1p2==7 && poder2p2==7 && poder3p2==7 && poder4p2==7){
				System.out.println("\nAún no puedes beber Elixir, aun tienes completos todos tus ataques");
			}
			else if(ataque1==5 || poder1p2<7 || poder2p2<7 || poder3p2<7 || poder4p2<7){
				
				
						poder1p2+=ep2;
						poder2p2+=ep2;
						poder3p2+=ep2;
						poder4p2+=ep2;
						ep2=0;
						if( poder1p2>7 || poder2p2>7 || poder3p2>7 || poder4p2>7){
						poder1p2=7;
						poder2p2=7;
						poder3p2=7;
						poder4p2=7;
						
						}
						System.out.println("\nRecargaste todos tus ataques");

					

				}
					pokemon2turn=false;
			}
		}
			}
	
		if(ev2<=300 && obp2==0){
					System.out.println("\nLo siento ya consumiste todo tu Oran berry , no podras aumentar tu vitalidad");
		}else if(ev2<=300){
					System.out.println("\nTu Vitalidad se esta agotando");
					System.out.println("\nPulsa 1 para usar OranBerry");
					System.out.println("\nPulsa 2 para denegar");
					int ob1=entradas.nextInt();
		if(ob1==1){
					ev2+=obp2;
					obp2=0;
					System.out.println("Recargaste tu energía a "+ ev2);
									

		}else if(ob1==2){
					System.out.println("Usalo cuando puedas");
					}
				} 
									

									pokemon2turn=false;
								}
								
							}
						}
					}


				}//Justo aqui se termina el ciclo en el que un pokemon se halla confundido y fallado dos turnos

				
					

					//Con esta variable termina el turno original
					pokemon2turn=(!pokemon2turn);
							
							
		
		//Todo lo Anterior es analgo para el turno del pokemon menos veloz 			
		}else {
					System.out.println("\nTurno de "+p1.getNombre()+":    Su vitalidad actual es "+ev1);

					System.out.println("\nElige un ataque:");
					System.out.println("\n1.Lanzallamas Danio:70");
					System.out.println("2.Ascuas Danio:10");
					System.out.println("3.Arañazo Danio:6");
					System.out.println("4.Pirotecnia  Danio:25");
					System.out.println("5. Beber Elixir");
					ataque2=entradas.nextInt();
					
		if (ataque2==1 && poder1p1==0) {
						System.out.println("\nYa no puedes usar Lanzallamas");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
				

		}else if(ataque2==1){
						
					
					ev2-=lanzallamas;
					System.out.println("\nAtacaste con Lanzallamas ");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder1p1--;
				
				
		}else if (ataque2==2 && poder2p1==0) {
						System.out.println("\nYa no puedes usar Ascuas");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
						
				

		}else if (ataque2==2) {
					
					
					ev2-=ascuas;
					System.out.println("\nAtacaste con Ascuas");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder2p1--;

		}else if (ataque2==3 && poder3p1==0) {
						System.out.println("\nYa no puedes usar Araniazo");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
						
				

		}else if(ataque2==3){
					
					
					ev2-=araniazo;
					System.out.println("\nUsaste el ataque Araniazo");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder3p1--;

		}else if (ataque2==4 && poder4p1==0) {
						System.out.println("Ya no puedes usar Pirotecnia");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
						
				

		}else if(ataque2==4){
					
					
					ev2-=pirotecina;
					System.out.println("\nAtacaste con Pirotecnia");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder4p1--;
				

				} if(ataque2==5){ 
			

			for (int j=0;j<2 ;j++ ) {
				if(pokemon2turn==false){
			 	
			 

				if(ep1==0){
					System.out.println("\nLo siento ya no puedes beber Elixir otra vez ");
				

				}else if( poder1p1==7 && poder2p1==7 && poder3p1==7 && poder4p1==7){
				System.out.println("\nAún no puedes beber Elixir, aun tienes completos todos tus ataques");
			}
			else if(ataque2==5 || poder1p1<7 || poder2p1<7 || poder3p1<7 || poder4p1<7){
				
				
						poder1p1+=ep1;
						poder2p1+=ep1;
						poder3p1+=ep1;
						poder4p1+=ep1;
						ep1=0;
						if( poder1p1>7 || poder2p1>7 || poder3p1>7 || poder4p1>7){
						poder1p1=7;
						poder2p1=7;
						poder3p1=7;
						poder4p1=7;
						
						}
						System.out.println("\nRecargaste todos tus ataques");

					

				}
					pokemon2turn=(!pokemon2turn);
			}
		}
			}


		


		if(ev1<=300 && obp1==0){
					System.out.println("\nLo siento ya consumiste todo tu Oran berry , no podras aumentar tu vitalidad");
		}else if(ev1<=300){
					System.out.println("\nTu Vitalidad se esta agotando");
					System.out.println("\nPulsa 1 para usar OranBerry");
					System.out.println("\nPulsa 2 para denegar");
					int ob2=entradas.nextInt();
					if(ob2==1){
					ev1+=obp2;
					obp1=0;
					System.out.println("\nRecargaste tu energía a "+ ev1);
									

		}else if(ob2==2){
					System.out.println("\nUsalo cuando puedas");
					}
				}  if(ataque2==1 && lanzallamas>=40 && poder1p1>0){
						int confundidop2=aleatorios.nextInt(100)+1;
						int fallarp2=aleatorios.nextInt(100)+1;


					if( confundidop2>=20 && confundidop2<=100){
						p2.setConfundido(true);
						System.out.println("\n "+p2.getNombre() +" Esta confundido :(");

						if(p2.getConfundido()==true  && fallarp2>=40 && fallarp2<=100){
							for (int i=0;i<3 ;i++ ) {
								if(pokemon2turn==false){

						System.out.println("\nFallas dos turnos "+p2.getNombre());

						System.out.println("********************************");
						System.out.println("\nTurno de "+p1.getNombre()+":    Su vitalidad es "+ev1);

					System.out.println("\nElige un ataque:");
					System.out.println("\n1.Lanzallamas Danio:70");
					System.out.println("2.Ascuas Danio:10");
					System.out.println("3.Arañazo Danio:6");
					System.out.println("4.Pirotecnia  Danio:25");
					System.out.println("5. Beber Elixir");
					ataque2=entradas.nextInt();
					
		if (ataque2==1 && poder1p1==0) {
						System.out.println("\nYa no puedes usar Lanzallamas");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
				

		}else if(ataque2==1){
						
					
					ev2-=lanzallamas;
					System.out.println("\nAtacaste con Lanzallamas ");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder1p1--;
				
				
		}else if (ataque2==2 && poder2p1==0) {
						System.out.println("\nYa no puedes usar Ascuas");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
						
				

		}else if (ataque2==2) {
					
					
					ev2-=ascuas;
					System.out.println("\nAtacaste con Ascuas");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder2p1--;

		}else if (ataque2==3 && poder3p1==0) {
						System.out.println("\nYa no puedes usar Araniazo");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
						
				

		}else if(ataque2==3){
					
					
					ev2-=araniazo;
					System.out.println("\nUsaste el ataque Araniazo");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder3p1--;

		}else if (ataque2==4 && poder4p1==0) {
						System.out.println("Ya no puedes usar Pirotecnia");
						System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
						
				

		}else if(ataque2==4){
					
					
					ev2-=pirotecina;
					System.out.println("\nAtacaste con Pirotecnia");
					System.out.println("\nLa Vitalidad de "+p2.getNombre()+" es "+ev2);
						
					poder4p1--;
				

				} if(ataque2==5){ 
			

			for (int j=0;j<2 ;j++ ) {
				if(pokemon2turn==false){
			 	
			 

				if(ep1==0){
					System.out.println("\nLo siento ya no puedes beber Elixir otra vez ");
				

				}else if( poder1p1==7 && poder2p1==7 && poder3p1==7 && poder4p1==7){
				System.out.println("\nAún no puedes beber Elixir, aun tienes completos todos tus ataques");
			}
			else if(ataque2==5 || poder1p1<7 || poder2p1<7 || poder3p1<7 || poder4p1<7){
				
				
						poder1p1+=ep1;
						poder2p1+=ep1;
						poder3p1+=ep1;
						poder4p1+=ep1;
						ep1=0;
						if( poder1p1>7 || poder2p1>7 || poder3p1>7 || poder4p1>7){
						poder1p1=7;
						poder2p1=7;
						poder3p1=7;
						poder4p1=7;
						
						}
						System.out.println("\nRecargaste todos tus ataques");

					

				}
					pokemon2turn=(!pokemon2turn);
			}
		}
			}


		


		if(ev1<=300 && obp1==0){
					System.out.println("\nLo siento ya consumiste todo tu Oran berry , no podras aumentar tu vitalidad");
		}else if(ev1<=300){
					System.out.println("\nTu Vitalidad se esta agotando");
					System.out.println("\nPulsa 1 para usar OranBerry");
					System.out.println("\nPulsa 2 para denegar");
					int ob2=entradas.nextInt();
					if(ob2==1){
					ev1+=obp2;
					obp1=0;
					System.out.println("\nRecargaste tu energía a "+ ev1);
									

		}else if(ob2==2){
					System.out.println("\nUsalo cuando puedas");
					}
				}
						
									

									pokemon2turn=true;
								}
								
							}
						}
					}


				}

						pokemon2turn=(!pokemon2turn);
					}//Aqui termina el turno del pokemon 2

							
				System.out.println("\n*********************************************");					


						/*Este if es en caso de que la vida e un pokemon sea menor
						o igual a cero, entonces el ciclo se termina y se muestra como ganador al rival 
						además de que realizamos las operaciones de sederle las monedas al ganador y 
						que el perdedor se quede sin nada*/
						if (ev1<=0) {
							
							System.out.println("\nLa energía de "+p1.getNombre()+ " es de "+ ev1);
							System.out.println("\nEl ganador es " +p2.getNombre());
							System.out.println("\nOh no!!! "+p1.getNombre()+" tendrá que dar sus "
																	+mp1+" mondeas a "+p2.getNombre());
							mp2+=mp1;
							mp1=0;

						
							System.out.println("\nAhora las monedas de "+p2.getNombre()+" ascienden a "+mp2+" felicidades!!");

							
							
						}else if (ev2<=0) {
							



							System.out.println("\nLa energía de "+p2.getNombre()+ " es de"+ev2);
							System.out.println("\nEl ganador es "+p1.getNombre());
							System.out.println("\nOh no!!! "+p2.getNombre()+" tendrá que dar sus "
																	+mp2+" mondeas a "+p1.getNombre());

							mp1+=mp2;
							mp2=0;
							
							System.out.println("\nAhora las monedas de "+p1.getNombre()+" ascienden a "+mp1+" felicidades!!");							

						}




					}
					}
				}

		
	/*Aqui establecimos un método toString para imprimir las caracteristicas de los Pokemon*/
	public String toString(){
			return"\nLes presentamos a " +nombre+" \nTipo: "+tipo+" \nEnergia  Vital: "+energíaVital+
		 "  \nVelocidad: "+velocidad;

	}



}

