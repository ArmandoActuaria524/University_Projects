public class usoPokemon{
	public static void main(String[] args) throws Exception{
		
		//Aqui creamos dos objetos de tipo mochila
		Mochila m1=new Mochila(200,7,250);
		Mochila m2=new Mochila(200,7,300);
		//Creamos dos objetos de tipo Pokemon
		//En la parte de la mochila, le agregamos los objetos mochila ya creados

		Pokemon p1= new Pokemon("Charmander","Fuego",500,false,m1,4);
		Pokemon p2= new Pokemon("Raichu","Electrico",500,false,m2,7);
		
		//Aquí se llama al método to String
		//System.out.println(p1);
		//System.out.println(p2);
		

		//Aqui agregamos el timer del juego Serpientes y Escaleras para dar varios segundos antes de que inicie la pelea
		Thread.sleep(1000);
  		for( int i = 10; i>=1; i--){
    	System.out.printf("         Entrando a la Arena en  .............................. in %d\r", i);
    	Thread.sleep(1000);
  					}

		Thread.sleep(500);
  		System.out.println("\n Bienvenidos a la Arena Pokemon");
  		Thread.sleep(500);

  		//Aquí llamamos al método pelear y que comience la batalla

  		
		p1.pelear(p1,p2,m1,m2);



	}
}