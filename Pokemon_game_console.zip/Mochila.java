import java.util.*;


public class Mochila{

	int oranBerry;//Oran berry
	int elixir;//Elixir
	int monedas;//Monedas
	//Establecemos un método constructor
	public Mochila(int ob,int e, int m){
		
		/*Cuando se cree un objeto de tipo mochila solo
		  se imprimiran los valores si el oran berry es igual a 200
		  si el elixir es igual a 7
		  y si las monedas estan en un rango de 1 a 400*/
		if (ob==200) {
		oranBerry=ob;}
		
		if (e==7) {
		elixir=e;}
		
		if(m>=1 && m<=400){
		monedas=m;}


	}

		//setters

		public void setOranBerry(int ob){

			oranBerry=ob;
		}
		
		public void  setElixir(int e){

			elixir=e;
		}


		public void setMonedas(int m){

			monedas=m;
		}


	

		//getters


		public int getOranBerry(){
			return oranBerry;
		}

		public int getElixir(){
			return elixir;
		}

		public int getMonedas(){
			return monedas;
		}



			

}